import pathlib
import matplotlib
import matplotlib.pyplot as plt
from distinctipy import distinctipy
from matplotlib.colors import ListedColormap
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import copy
from .data_functions import *

font0=matplotlib.font_manager.FontProperties()
font0.set_style('italic')


def mkdir(out_dir):
    pathlib.Path(out_dir).mkdir(parents=True, exist_ok=True)


def interpolate_nan(spec_raw, nan_map, wavelengths_org):
    """"
        interpolate nan values in spectra
        Inputs:
            spec_raw: spectra array
            nan_map: nan-value map with same dimensions as spec_raw
            wavelengths_org: wavelength array
    """
    out = copy.deepcopy(spec_raw)
    wavelengths = np.array(wavelengths_org)
    for i, (specrow, nanrow) in enumerate(zip(spec_raw, nan_map)):
        out[i, nanrow] = np.interp(wavelengths[nanrow], wavelengths[~nanrow], specrow[~nanrow])

    return out


def plot_spectra_zsoil_microplastic_snv(csv_file, wavelength_f, xlim, outfile,
                                        is_zscore=True, ndiff=7, outcsv=None, ylim=None):
    """
        Plot soil-subtracted SNV spectra of MP mixtures for PE and PA
        Inputs:
            csv_file: csv data file
            wavelength_f: wavelength file
            xlim: [min, max] of x-axis
            outfile: plot file path
            is_zscore: calculate Z-score of spectra if True
            ndiff: DIFF gap - may be deleted later
            outcsv: output csv file in case
            ylim: [min, max] of y-axis
    """
    from sklearn.preprocessing import StandardScaler
    import pandas as pd
    outfile_org = outfile
    linewidth = 5
    fontsize = 40
    # read the CSV file
    table = pd.read_csv(csv_file)
    wavelengths_org = np.array(read_wavelengths(wavelength_f))
    ttable = table.to_numpy()
    if ylim is None:
        ylim = [-3.5, 4.5]
    for mm, mode in enumerate(["pe", "pa"]):
        if mode == "all":
            iclasses = list(range(1, 21))
            strclasses = [
                "100% Soil", "0.01% PE", "0.03% PE", "0.07% PE", "0.1% PE",
                "0.2% PE", "0.4% PE", "0.6% PE", "0.8% PE", "1.6% PE", "6.9% PE",
                "0.01% PA", "0.03% PA", "0.07% PA", "0.1% PA", "0.2% PA",
                "0.4% PA", "0.6% PA", "5% PA", "11.3% PA",
            ]
            ncols_leg = 5
        elif mode == "pe":
            iclasses = list(range(1, 12))
            strclasses = [
                "Soil",
                "0.01%", "0.03%", "0.07%", "0.1%",
                "0.2%", "0.4%", "0.6%", "0.8%", "1.6%", "6.9%",
            ]
            ncols_leg = 4
            plot_height = 0.75
        elif mode == "pa":
            iclasses = [1, 12, 13, 14, 15, 16, 17, 18, 19, 20]
            strclasses = [
                "Soil",
                "0.01%", "0.03%", "0.07%", "0.1%", "0.2%",
                "0.4%", "0.6%", "5%", "11.3%",
            ]
            ncols_leg = 4
            plot_height = 0.75
        else:
            raise Exception(f"Invalid mode value {mode}")

        fp, fn, fex = fileparts(outfile_org)
        outfile = fr"{fp}/{fn}_{mode}{fex}"
        # New_Class (-4),PA_Concentration (-3),PE_Concentration (-2), Experiment (-1)

        sample_weights = np.sqrt(ttable[np.in1d(ttable[:, -4], iclasses), 3])
        sample_weights /= np.sum(sample_weights)
        # print(f"sum of weights: {np.sum(sample_weights)}")
        # assert(np.sum(sample_weights) == 1)
        classes = ttable[np.in1d(ttable[:, -4], iclasses), -4]
        spectra_raw = ttable[np.in1d(ttable[:, -4], iclasses), 4:-5]

        # here we need to remove nan values
        nan_map = np.isnan(spectra_raw)
        nan_exist = np.any(nan_map)
        # print(f"Contain any nan? {nan_exist}")
        if nan_exist:
            nan_rows = np.any(nan_map, axis=1)
            # print(f"nan_row shape {nan_rows.shape}")
            spectra_raw[nan_rows, :] = interpolate_nan(spectra_raw[nan_rows, :], nan_map[nan_rows, :], wavelengths_org)

        spectra_raw = savgol(spectra_raw)
        if np.mean(spectra_raw) > 1:  # divide by 100 if intensities are percentrage
            spectra_raw /= 100.0

        spectra_raw = -np.log10(spectra_raw)
        # let's draw raw, snv, zsnv, zmst_diff7
        strpreprocs = [f"SNV-S"]
        if is_zscore:
            strpreprocs = [f"SNV-ZS"]

        nrows = 1
        ncols = 1
        fig, axms = plt.subplots(nrows, ncols, constrained_layout=True, figsize=(16.5, 10))
        axs = [axms]  # .flatten()
        cm = plt.get_cmap('gist_rainbow')
        wavelengths = wavelengths_org[(wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])]
        d = np.reshape(np.array(wavelengths), (len(wavelengths), 1))
        for i, ax in enumerate(axs):
            raw = copy.deepcopy(spectra_raw)
            raw = np.array(raw, dtype=np.float64)
            spectra = snv(raw[:, (wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])])
            wavelengths = wavelengths_org[(wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])]
            if is_zscore:
                zscaler = StandardScaler().fit(spectra[:, :], sample_weight=sample_weights)
                spectra = zscaler.transform(spectra)

            spec0 = spectra[(classes == 1), :]
            mean0 = np.mean(spec0.T, axis=1)

            for j, iclass in enumerate(iclasses):
                strclass = strclasses[j]
                spec = spectra[(classes == iclass), :]
                if spec is None or spec.shape[0] == 0:
                    continue
                lines = ax.plot(wavelengths,
                               np.mean(spec.T, axis=1)-mean0,
                               linewidth=linewidth, label=strclass)

                lines[0].set_color(cm(j / len(iclasses)))

                a_colum = np.mean(spec.T, axis=1)-mean0

                a_colum = np.reshape(a_colum, (len(wavelengths), 1))
                d = np.append(d, a_colum, 1)

            ax.set_ylabel(f"{strpreprocs[i]} intensity", fontsize=fontsize)
            ax.set_xlabel("Wavelength (nm)", fontsize=fontsize)
            ax.set_xlim(xlim)
            ax.set_ylim(ylim)
            ax.set_facecolor((1, 1, 1))
            ax.grid(color=(0.9, 0.9, 0.9), linewidth=0.3)
            ax.spines[:].set_color((0.9, 0.9, 0.9))
            ax.tick_params(axis='both', colors="black")
            ax.yaxis.label.set_color((0, 0, 0))
            ax.xaxis.label.set_color((0, 0, 0))
            # ax.set_ylim(yrange)
            plt.setp(ax.get_xticklabels(), fontsize=fontsize)
            plt.setp(ax.get_yticklabels(), fontsize=fontsize)

        allhandles, alllabels = ax.get_legend_handles_labels()
        leg = fig.legend(allhandles, alllabels,  # bbox_to_anchor=(0, 1.15),
                          loc='upper center', ncol=ncols_leg, frameon=False,
                          fontsize=fontsize, facecolor="white")
        fig.tight_layout(rect=[0, 0, 1, plot_height])
        plt.savefig(outfile, dpi=300)
        plt.show(block=False)
        plt.pause(0.01)
        plt.close('all')

        if outcsv is not None:
            colnames = [preproc + "_" + strclass for preproc in strpreprocs for strclass in strclasses]
            colnames = ["Wavelength"] + colnames
            df = pd.DataFrame(data=d, dtype=np.float64, columns=colnames)

            df.to_csv(outcsv, index=False)


def plot_spectra_zsoil_microplastic_pure_snv(csv_file, wavelength_f, xlim, outfile,
                                        is_zscore=True, ndiff=7, outcsv=None):
    """
        Plot soil-subtracted spectra of PURE soil, PE, and PA
        Inputs:
            csv_file: csv data file
            wavelength_f: wavelength file
            xlim: [min, max] of x-axis
            outfile: plot file path
            is_zscore: calculate Z-score of spectra if True
            ndiff: DIFF gap - may be deleted later
            outcsv: output csv file in case
    """
    from sklearn.preprocessing import StandardScaler
    import pandas as pd
    from scipy import stats
    outfile_org = outfile
    linewidth = 5
    fontsize = 40
    # read the CSV file
    table = pd.read_csv(csv_file)
    wavelengths_org = np.array(read_wavelengths(wavelength_f))
    ttable = table.to_numpy()

    mode = "pure"
    iclasses_org = [1, 2, 3, 4, 5, 6, 7]
    iclasses = [1, 6, 7]
    strclasses = ["Soil 100%", "PE 100%", "PA 100%"]

    ncols_leg = 5
    plot_height = 0.90

    fp, fn, fex = fileparts(outfile_org)
    outfile = fr"{fp}/{fn}_{mode}{fex}"

    classes = ttable[np.in1d(ttable[:, -1], iclasses_org), -1]
    spectra_raw = ttable[np.in1d(ttable[:, -1], iclasses_org), 3:-1]

    # here we need to remove nan values
    nan_map = np.isnan(spectra_raw)
    nan_exist = np.any(nan_map)
    # print(f"Contain any nan? {nan_exist}")
    if nan_exist:
        nan_rows = np.any(nan_map, axis=1)
        # print(f"nan_row shape {nan_rows.shape}")
        spectra_raw[nan_rows, :] = interpolate_nan(spectra_raw[nan_rows, :], nan_map[nan_rows, :], wavelengths_org)

    if np.mean(spectra_raw) > 1:  # divide by 100 if intensities are percentrage
        spectra_raw /= 100.0

    spectra_raw = -np.log10(spectra_raw)

    # let's draw raw, snv, zsnv, zmst_diff7
    strpreprocs = [f"SNV-S"]
    if is_zscore:
        strpreprocs = [f"SNV-ZS"]

    nrows = 1
    ncols = 1
    fig, axms = plt.subplots(nrows, ncols, constrained_layout=True, figsize=(16.5, 10))
    axs = [axms]  # .flatten()
    cm = plt.get_cmap('gist_rainbow')
    wavelengths = wavelengths_org[(wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])]
    d = np.reshape(np.array(wavelengths), (len(wavelengths), 1))
    for i, ax in enumerate(axs):
        raw = copy.deepcopy(spectra_raw)
        raw = np.array(raw, dtype=np.float64)
        spectra = snv(raw[:, (wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])])
        wavelengths = wavelengths_org[(wavelengths_org >= xlim[0]) & (wavelengths_org <= xlim[1])]

        if is_zscore:
            zscaler = StandardScaler().fit(spectra[:, :])
            spectra = zscaler.transform(spectra)

        spec0 = spectra[(classes == 1), :]
        mean0 = np.mean(spec0.T, axis=1)

        for j, iclass in enumerate(iclasses):
            strclass = strclasses[j]
            spec = spectra[(classes == iclass), :]
            if spec is None or spec.shape[0] == 0:
                continue
            lines = ax.plot(wavelengths,
                           np.mean(spec.T, axis=1)-mean0,
                           linewidth=linewidth, label=strclass)

            lines[0].set_color(cm(j / len(iclasses)))

            a_colum = np.mean(spec.T, axis=1)-mean0

            a_colum = np.reshape(a_colum, (len(wavelengths), 1))
            d = np.append(d, a_colum, 1)

        ax.set_ylabel(f"{strpreprocs[i]} intensity", fontsize=fontsize)
        ax.set_xlabel("Wavelength (nm)", fontsize=fontsize)
        ax.set_xlim(xlim)
        ax.set_ylim([-3.5, 4])
        ax.set_facecolor((1, 1, 1))
        ax.grid(color=(0.9, 0.9, 0.9), linewidth=0.3)
        ax.spines[:].set_color((0.9, 0.9, 0.9))
        ax.tick_params(axis='both', colors="black")
        ax.yaxis.label.set_color((0, 0, 0))
        ax.xaxis.label.set_color((0, 0, 0))
        # ax.set_ylim(yrange)
        plt.setp(ax.get_xticklabels(), fontsize=fontsize)
        plt.setp(ax.get_yticklabels(), fontsize=fontsize)

    allhandles, alllabels = ax.get_legend_handles_labels()
    leg = fig.legend(allhandles, alllabels,  # bbox_to_anchor=(0, 1.15),
                      loc='upper center', ncol=ncols_leg, frameon=False,
                      fontsize=fontsize, facecolor="white")
    fig.tight_layout(rect=[0, 0, 1, plot_height])
    plt.savefig(outfile, dpi=300)
    plt.show(block=False)
    plt.pause(0.01)
    plt.close('all')

    if outcsv is not None:
        colnames = [preproc + "_" + strclass for preproc in strpreprocs for strclass in strclasses]
        colnames = ["Wavelength"] + colnames
        df = pd.DataFrame(data=d, dtype=np.float64, columns=colnames)

        df.to_csv(outcsv, index=False)


def classification_scores(model, X_test, y_test):
    """
        Calculate and return
            accuracy,
            matthew's correlation coefficient,
            precision,
            recall,
            F1 score
              from model and data.
        Inputs:
            model: sklearn model
            X_test: input matrix for the model
            y_test: ground truth labels for the input matrix
    """
    from sklearn.metrics import matthews_corrcoef as b_score
    from sklearn.metrics import precision_recall_fscore_support as prfs_score
    acc = model.score(X_test, y_test)
    predicted = model.predict(X_test)
    mcc = b_score(y_test, predicted)  # mcc is matthew's correlation coefficient
    pr, re, ff, su = prfs_score(y_test, predicted, average="weighted")
    return [acc, mcc, pr, re, ff]


def perform_hyperopt(spectra, classes, ppl, grid, ncv=10, nrepeat=1, random_state=45, kwargs=None):
    """
        Optimize hyperparameters in models of pipeline
        with gridsearch using repeated v fold crossvalidation.
        Inputs:
            spectra: input matrix for the model
            classes: ground truth labels for the input matrix
            ppl: pipeline of a machine learning model including preprocessing procedure
            grid: dictionary of possible hyperparameter value space
            ncv: number of folds for cross validation
            nrepeat: number of repetitions for cross validation
            random_state: random seed,
            kwargs: dictionary of extra arguments usually for sample weight specification
        Return: dictionary of hyperparameter value selected
    """
    from sklearn.model_selection import GridSearchCV
    from sklearn.model_selection import cross_val_score, RepeatedKFold
    import warnings
    warnings.filterwarnings("ignore")
    cv = RepeatedKFold(n_splits=ncv, n_repeats=nrepeat, random_state=random_state)
    searched = GridSearchCV(ppl, param_grid=grid, refit=True, cv=cv, scoring="balanced_accuracy")
    if kwargs is None:
        searched.fit(spectra, classes)
    else:
        searched.fit(spectra, classes, **kwargs)
    dict_opthp = searched.best_params_
    corrected_dict = {k.replace("estimator__", ""): v for k, v in dict_opthp.items()}
    print(f"Hyperparams: {corrected_dict}")
    return corrected_dict


def classification_pca_spectra_microplastic_1st(csv_file, wavelength_f, xlim,
                                                npc=5, ndiff=7,
                                                iclasses = [1, 2, 3, 4, 5, 6, 7]):
    """
        For training and evaluation of classification models with separate datasets
        from individual experiments. It also includes hyperparameter tuning.
        Inputs:
            csv_file: csv data file
            wavelength_f: wavelength file
            xlim: [min, max] of x-axis
            npc: number of PCs (and PLO components) to use
            ndiff: DIFF gap
            iclasses: unique class values for csv file
    """
    import pandas as pd
    from sklearn.decomposition import PCA
    from sklearn import svm
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import matthews_corrcoef as b_score
    from sklearn.metrics import precision_recall_fscore_support as prfs_score
    test_pcnt = 0.2
    # read the CSV file
    table = pd.read_csv(csv_file)
    ttable = table.to_numpy()

    wavelengths_org = np.array(read_wavelengths(wavelength_f))
    wstart, wend = xlim

    # organize this part of code with pipeline
    print(f"{wstart}-{wend}nm: {len(iclasses)} classes, test data %: {test_pcnt*100}, "
          f"{npc}")

    classes = ttable[np.in1d(ttable[:, -1], iclasses), -1]
    spectra_raw = ttable[np.in1d(ttable[:, -1], iclasses), 3:-1]
    # absorbance
    spectra_raw = -np.log10(spectra_raw[:, (wavelengths_org >= wstart) & (wavelengths_org <= wend)])

    # print(spectra_raw.shape)
    raw = copy.deepcopy(spectra_raw)
    raw = np.array(raw, dtype=np.float64)

    # we may have more options for preprocessing later
    spectra = snvd_diff(raw, ndiff)  # msc_diff(raw, 7)

    scaler = StandardScaler()
    pca_transform = PCA(n_components=npc)
    plsda_transform = PLSDA(n_components=npc)

    # initial model definitions
    clf_pca_lr = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced")
    clf_pca_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced")
    clf_pca_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced")
    clf_pls_lr = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced")
    clf_pls_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced")
    clf_pls_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced")

    # construct data process pipelines for hyperparameter optimizations
    ppl_pca_lr = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_lr)])
    ppl_pca_svm = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm)])
    ppl_pca_svm2 = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm2)])
    ppl_pls_lr = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_lr)])
    ppl_pls_svm = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm)])
    ppl_pls_svm2 = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm2)])

    # hyperparameter spaces
    mlr_grid = {
        'estimator__penalty': ['l1', 'l2', 'elasticnet'],
        'estimator__C': np.logspace(-4, 4, 20)
    }
    svm1_grid = {"estimator__C": [0.1, 1, 10, 100, 1000]}
    svm2_grid = {
        'estimator__C': [0.1, 1, 10, 100, 1000],
        'estimator__gamma': [1, 0.1, 0.01, 0.001, 0.0001]
    }

    # find the best hyperparameters
    print("Optimizing hyperaparameters for PCA-LR")
    hp_pca_mlr = perform_hyperopt(spectra, classes, ppl_pca_lr, mlr_grid)
    print("Optimizing hyperaparameters for PCA-SVM1")
    hp_pca_svm = perform_hyperopt(spectra, classes, ppl_pca_svm, svm1_grid)
    print("Optimizing hyperaparameters for PCA-SVM2")
    hp_pca_svm2 = perform_hyperopt(spectra, classes, ppl_pca_svm2, svm2_grid)
    print("Optimizing hyperaparameters for PLSDA-LR")
    hp_pls_mlr = perform_hyperopt(spectra, classes, ppl_pls_lr, mlr_grid)
    print("Optimizing hyperaparameters for PLSDA-SVM1")
    hp_pls_svm = perform_hyperopt(spectra, classes, ppl_pls_svm, svm1_grid)
    print("Optimizing hyperaparameters for PLSDA-SVM2")
    hp_pls_svm2 = perform_hyperopt(spectra, classes, ppl_pls_svm2, svm2_grid)

    # redefine models and pipelines with the optimum hyperparameters
    clf_pca_lda = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced", **hp_pca_mlr)
    clf_pca_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced", **hp_pca_svm)
    clf_pca_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced", **hp_pca_svm2)
    ppl_pca_lda = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_lda)])
    ppl_pca_svm = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm)])
    ppl_pca_svm2 = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm2)])

    clf_pls_lda = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced", **hp_pls_mlr)
    clf_pls_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced", **hp_pls_svm)
    clf_pls_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced", **hp_pls_svm2)
    ppl_pls_lda = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_lda)])
    ppl_pls_svm = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm)])
    ppl_pls_svm2 = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm2)])

    # pca1 = pca_transform.transform(spectra)
    X_train, X_test, y_train, y_test = train_test_split(spectra, classes,
                                                        test_size=test_pcnt, random_state=45)

    clf_pca_svm_res = ppl_pca_svm.fit(X_train, y_train)
    clf_pca_svm2_res = ppl_pca_svm2.fit(X_train, y_train)
    clf_pca_lda_res = ppl_pca_lda.fit(X_train, y_train)
    clf_pls_svm_res = ppl_pls_svm.fit(X_train, y_train)
    clf_pls_svm2_res = ppl_pls_svm2.fit(X_train, y_train)
    clf_pls_lda_res = ppl_pls_lda.fit(X_train, y_train)

    model_names = ["PCA-LR", "PCA-SVM1", "PCA-SVM2", "PLS-LR", "PLS-SVM1", "PLS-SVM2", ]
    models = [clf_pca_lda_res, clf_pca_svm_res, clf_pca_svm2_res, clf_pls_lda_res, clf_pls_svm_res, clf_pls_svm2_res, ]
    metric_names = ["ACC", "MCC", ]  # ["ACC", "MCC", "PRE", "REC", "F1", ]

    for i, mname in enumerate(model_names):
        for j, mename in enumerate(metric_names):
            print(f"{mname}-{mename}\t", end="")
    print()

    for i, (mname, model) in enumerate(zip(model_names, models)):
        acc = model.score(X_test, y_test)
        predicted = model.predict(X_test)
        mcc = b_score(y_test, predicted)
        pr, re, ff, su = prfs_score(y_test, predicted, average="weighted")
        score_vals = [acc, mcc]
        # print(f"{mname}: ")
        for j, (mename, sval) in enumerate(zip(metric_names, score_vals)):
            print(f"{sval * 100:.0f}\t", end="")
        # print()

    print()


def list_print(lst, format=".2f"):
    """Print a list in a specified format."""
    for i, x in enumerate(lst):
        print(f"{x:{format}}", end="")
        if i < len(lst) - 1:
            print(f", ", end="")

    print()


def classification_pca_spectra_microplastic_2nd(csv_file, wavelength_f, xlim, class_group=None,
                                                      npc=5, ndiff=7):
    """
        For training and evaluation of classification models with combined dataset
        from three experiments. It also includes hyperparameter tuning.
        Inputs:
            csv_file: csv data file
            wavelength_f: wavelength file
            xlim: [min, max] of x-axis
            class_group: dictionary from original classes (20) to user-specified classes.
            npc: number of PCs (and PLO components) to use
            ndiff: DIFF gap
    """

    import pandas as pd
    from sklearn.decomposition import PCA
    from sklearn import svm
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import matthews_corrcoef as b_score
    from sklearn.metrics import precision_recall_fscore_support as prfs_score
    random_state = 42  # 42, 25, 101
    test_pcnt = 0.2
    # read the CSV file
    table = pd.read_csv(csv_file)
    ttable = table.to_numpy()

    wavelengths_org = np.array(read_wavelengths(wavelength_f))
    wstart, wend = xlim

    iclasses = list(range(1, 21))
    strclasses = [
        "100% Soil", "0.01% PE", "0.03% PE", "0.07% PE", "0.1% PE",
        "0.2% PE", "0.4% PE", "0.6% PE", "0.8% PE", "1.6% PE", "6.9% PE",
        "0.01% PA", "0.03% PA", "0.07% PA", "0.1% PA", "0.2% PA",
        "0.4% PA", "0.6% PA", "5% PA", "11.3% PA",
    ]

    sample_weights = np.sqrt(ttable[np.in1d(ttable[:, -4], iclasses), 3])
    experiments = ttable[np.in1d(ttable[:, -4], iclasses), -1]
    classes_org = ttable[np.in1d(ttable[:, -4], iclasses), -4]
    if class_group is not None:  # specified groups
        classes = np.vectorize(class_group.get)(classes_org)
    else:  # 20 classes
        classes = classes_org.copy()

    spectra_raw = ttable[np.in1d(ttable[:, -4], iclasses), 4:-5]

    # here we need to remove nan values
    nan_map = np.isnan(spectra_raw)
    nan_exist = np.any(nan_map)
    # print(f"Contain any nan? {nan_exist}")
    if nan_exist:
        nan_rows = np.any(nan_map, axis=1)
        # print(f"nan_row shape {nan_rows.shape}")
        spectra_raw[nan_rows, :] = interpolate_nan(spectra_raw[nan_rows, :], nan_map[nan_rows, :], wavelengths_org)

    spectra_raw = -np.log10(spectra_raw[:, (wavelengths_org >= wstart) & (wavelengths_org <= wend)])
    raw = copy.deepcopy(spectra_raw)
    raw = np.array(raw, dtype=np.float64)
    spectra = snvd_diff(raw, ndiff)  # msc_diff(raw, 7)

    print(f"{wstart}-{wend}nm: {len(np.unique(classes))} classes, "
          f"Preprocess: SNVD_Diff{ndiff}, "
          f"test data %: {test_pcnt*100}, N. PCs: {npc}")

    scaler = StandardScaler()
    pca_transform = PCA(n_components=npc)
    plsda_transform = PLSDA(n_components=npc)

    # initial model definitions
    clf_pca_lr = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced")
    clf_pca_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced")
    clf_pca_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced")
    clf_pls_lr = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced")
    clf_pls_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced")
    clf_pls_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced")

    # construct data process pipelines for hyperparameter optimizations
    ppl_pca_lr = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_lr)])
    ppl_pca_svm = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm)])
    ppl_pca_svm2 = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm2)])
    ppl_pls_lr = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_lr)])
    ppl_pls_svm = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm)])
    ppl_pls_svm2 = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm2)])

    # hyperparameter spaces
    mlr_grid = {
        'estimator__penalty': ['l1', 'l2', 'elasticnet'],
        'estimator__C': np.logspace(-4, 4, 20)
    }
    svm1_grid = {"estimator__C": [0.1, 1, 10, 100, 1000]}
    svm2_grid = {
        'estimator__C': [0.1, 1, 10, 100, 1000],
        'estimator__gamma': [1, 0.1, 0.01, 0.001, 0.0001]
    }
    # this is important for model building with sample weights
    kwargs = {'scaler__sample_weight': sample_weights, 'estimator__sample_weight': sample_weights}

    # find the best hyperparameters
    print("Optimizing hyperaparameters for PCA-LR")
    hp_pca_mlr = perform_hyperopt(spectra, classes, ppl_pca_lr, mlr_grid, kwargs=kwargs)
    print("Optimizing hyperaparameters for PCA-SVM1")
    hp_pca_svm = perform_hyperopt(spectra, classes, ppl_pca_svm, svm1_grid, kwargs=kwargs)
    print("Optimizing hyperaparameters for PCA-SVM2")
    hp_pca_svm2 = perform_hyperopt(spectra, classes, ppl_pca_svm2, svm2_grid, kwargs=kwargs)
    print("Optimizing hyperaparameters for PLSDA-LR")
    hp_pls_mlr = perform_hyperopt(spectra, classes, ppl_pls_lr, mlr_grid, kwargs=kwargs)
    print("Optimizing hyperaparameters for PLSDA-SVM1")
    hp_pls_svm = perform_hyperopt(spectra, classes, ppl_pls_svm, svm1_grid, kwargs=kwargs)
    print("Optimizing hyperaparameters for PLSDA-SVM2")
    hp_pls_svm2 = perform_hyperopt(spectra, classes, ppl_pls_svm2, svm2_grid, kwargs=kwargs)

    # redefine models and pipelines with the optimum hyperparameters
    clf_pca_lda = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced", **hp_pca_mlr)
    clf_pca_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced", **hp_pca_svm)
    clf_pca_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced", **hp_pca_svm2)
    ppl_pca_lda = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_lda)])
    ppl_pca_svm = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm)])
    ppl_pca_svm2 = Pipeline([('scaler', scaler), ('pca', pca_transform), ('estimator', clf_pca_svm2)])

    clf_pls_lda = LogisticRegression(max_iter=10000, multi_class='multinomial', class_weight="balanced", **hp_pls_mlr)
    clf_pls_svm = svm.SVC(kernel='linear', random_state=42, class_weight="balanced", **hp_pls_svm)
    clf_pls_svm2 = svm.SVC(kernel='rbf', random_state=42, class_weight="balanced", **hp_pls_svm2)
    ppl_pls_lda = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_lda)])
    ppl_pls_svm = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm)])
    ppl_pls_svm2 = Pipeline([('scaler', scaler), ('pca', plsda_transform), ('estimator', clf_pls_svm2)])

    index_train, index_test, _, _ = train_test_split(np.array(list(range(spectra.shape[0]))), classes_org,
                                                        test_size=test_pcnt, random_state=random_state)
    X_train = spectra[index_train, :]
    X_test = spectra[index_test, :]
    y_train = classes[index_train]
    y_test = classes[index_test]
    w_train = sample_weights[index_train]
    w_test = sample_weights[index_test]

    kwargs = {'scaler__sample_weight': w_train, 'estimator__sample_weight': w_train}

    clf_pca_svm_res = ppl_pca_svm.fit(X_train, y_train, **kwargs)
    clf_pca_svm2_res = ppl_pca_svm2.fit(X_train, y_train, **kwargs)
    clf_pca_lda_res = ppl_pca_lda.fit(X_train, y_train, **kwargs)
    clf_pls_svm_res = ppl_pls_svm.fit(X_train, y_train, **kwargs)
    clf_pls_svm2_res = ppl_pls_svm2.fit(X_train, y_train, **kwargs)
    clf_pls_lda_res = ppl_pls_lda.fit(X_train, y_train, **kwargs)

    model_names = ["PCA-LR", "PCA-SVM1", "PCA-SVM2", "PLS-LR", "PLS-SVM1", "PLS-SVM2", ]
    models = [clf_pca_lda_res, clf_pca_svm_res, clf_pca_svm2_res, clf_pls_lda_res, clf_pls_svm_res, clf_pls_svm2_res, ]
    metric_names = ["ACC", "MCC", ]  # ["ACC", "MCC", "PRE", "REC", "F1", ]

    for i, mname in enumerate(model_names):
        for j, mename in enumerate(metric_names):
            print(f"{mname}-{mename}\t", end="")
    print()

    for i, (mname, model) in enumerate(zip(model_names, models)):
        acc = model.score(X_test, y_test)
        predicted = model.predict(X_test)
        mcc = b_score(y_test, predicted)
        pr, re, ff, su = prfs_score(y_test, predicted, average="weighted")
        score_vals = [acc, mcc]
        # print(f"{mname}: ")
        for j, (mename, sval) in enumerate(zip(metric_names, score_vals)):
            print(f"{sval * 100:.0f}\t", end="")

    print()


def plot_umap_tsne_spectra_mp(csv_file, wavelength_f, xlim, outfile,
                                            npc=20, ndiff=7, by_experiment=False, is_log=True, outcsv=None):
    """
        Plot UMAP and t-SNE plots from PCs of spectra of MP samples
            Inputs:
                csv_file: csv data file
                wavelength_f: wavelength file
                xlim: [min, max] of x-axis
                outfile: output path for resulting chart
                npc: number of PCs (and PLO components) to use
                ndiff: DIFF gap
                by_experiment: set it False always as it is from old code
                is_log: set it True always as it is from old code
                outcsv: output file path of chart data - was not tested

    """
    import pandas as pd
    from sklearn.decomposition import PCA
    import umap
    from sklearn.manifold import TSNE as tsne
    is_zscore = True
    # read the CSV file
    table = pd.read_csv(csv_file)
    ttable = table.to_numpy()

    wavelengths_org = np.array(read_wavelengths(wavelength_f))
    wstart, wend = xlim

    if by_experiment:
        iclasses = list(range(1, 4))
        strclasses = [
            "Exp. 1", "Exp. 2", "Exp. 3",
        ]
        sample_weights = np.sqrt(ttable[np.in1d(ttable[:, -1], iclasses), 3])
        sample_weights /= np.sum(sample_weights)
        # print(f"sum of weights: {np.sum(sample_weights)}")

        classes = ttable[np.in1d(ttable[:, -1], iclasses), -1]
        spectra_raw = ttable[np.in1d(ttable[:, -1], iclasses), 4:-5]
        fp, fn, fex = fileparts(outfile)
        outfile = fr"{fp}/{fn}_exp{fex}"
    else:
        iclasses = list(range(1, 21))
        strclasses = [
            "100% Soil", "0.01% PE", "0.03% PE", "0.07% PE", "0.1% PE",
            "0.2% PE", "0.4% PE", "0.6% PE", "0.8% PE", "1.6% PE", "6.9% PE",
            "0.01% PA", "0.03% PA", "0.07% PA", "0.1% PA", "0.2% PA",
            "0.4% PA", "0.6% PA", "5% PA", "11.3% PA",
        ]
        sample_weights = np.sqrt(ttable[np.in1d(ttable[:, -4], iclasses), 3])
        sample_weights /= np.sum(sample_weights)
        # print(f"sum of weights: {np.sum(sample_weights)}")

        classes = ttable[np.in1d(ttable[:, -4], iclasses), -4]
        spectra_raw = ttable[np.in1d(ttable[:, -4], iclasses), 4:-5]


    # here we need to remove nan values
    nan_map = np.isnan(spectra_raw)
    nan_exist = np.any(nan_map)
    # print(f"Contain any nan? {nan_exist}")
    if nan_exist:
        nan_rows = np.any(nan_map, axis=1)
        # print(f"nan_row shape {nan_rows.shape}")
        spectra_raw[nan_rows, :] = interpolate_nan(spectra_raw[nan_rows, :], nan_map[nan_rows, :], wavelengths_org)

    if is_log:
        spectra_raw = -np.log10(spectra_raw[:, (wavelengths_org >= wstart) & (wavelengths_org <= wend)])
        spectra = snvd_diff(spectra_raw, ndiff)
    else:
        spectra = spectra_raw[:, (wavelengths_org >= wstart) & (wavelengths_org <= wend)]

    if is_zscore:
        scaler = StandardScaler()
        spectra = scaler.fit_transform(spectra, sample_weight=sample_weights)

    # find unique color list of 21 automatically
    color_list = distinctipy.get_colors(21, rng=12, exclude_colors=[(0.0, 1.0, 0.0), (1.0, 0.0, 0.0), (1.0, 1.0, 1.0)])
    # print(color_list)
    cm = ListedColormap(color_list)

    pca_transform = PCA(n_components=npc)
    pca = pca_transform.fit(spectra)
    print(f"Explained (%): {np.sum(pca_transform.explained_variance_ratio_) * 100}")
    pca1 = pca_transform.transform(spectra)
    str_classes = [strclasses[x-1] for x in np.int32(classes)]
    strpreproc = f"SNVD-DIFF{ndiff}-Z PC1-{npc}"
    fontsize = 14
    fig, axs = plt.subplots(1, 2, constrained_layout=True, figsize=(12.5, 6))

    # draw UMAP
    n_neighbors = 5  # 15
    min_dist = 0.8  # 0.1
    n_components = 2
    metric = "euclidean"
    umap_reducer = umap.UMAP(n_neighbors=n_neighbors,
        min_dist=min_dist,
        n_components=n_components,
        metric=metric)

    umap_embedding = umap_reducer.fit_transform(pca1)
    ax = axs[0]
    for iclass in iclasses:
        scatter = ax.scatter(
            umap_embedding[classes == iclass, 0],
            umap_embedding[classes == iclass, 1],
            c=cm((iclass -1) / len(iclasses)),
            label=strclasses[iclass-1]
        )
    ax.set_aspect('equal', 'datalim')
    ax.set_ylabel(f"{strpreproc} UMAP 2", fontsize=fontsize)
    ax.set_xlabel(f"{strpreproc} UMAP 1", fontsize=fontsize)
    ax.set_facecolor((1, 1, 1))
    ax.grid(color=(0.9, 0.9, 0.9), linewidth=0.3)
    ax.spines[:].set_color((0.9, 0.9, 0.9))
    ax.tick_params(axis='both', colors="black")
    ax.yaxis.label.set_color((0, 0, 0))
    ax.xaxis.label.set_color((0, 0, 0))
    plt.setp(ax.get_xticklabels(), fontsize=fontsize)
    plt.setp(ax.get_yticklabels(), fontsize=fontsize)

    # draw TSNE
    perplexity = 3
    tsne_reducer = tsne(n_components=2, learning_rate='auto',
                        init='random', perplexity=perplexity)
    tsne_embedding = tsne_reducer.fit_transform(pca1)

    ax = axs[1]
    for iclass in iclasses:
        scatter = ax.scatter(
            tsne_embedding[classes == iclass, 0],
            tsne_embedding[classes == iclass, 1],
            c=cm((iclass -1) / len(iclasses)),
            label=strclasses[iclass-1]
        )
    ax.set_aspect('equal', 'datalim')
    ax.set_ylabel(f"{strpreproc} TSNE 2", fontsize=fontsize)
    ax.set_xlabel(f"{strpreproc} TSNE 1", fontsize=fontsize)
    ax.set_facecolor((1, 1, 1))
    ax.grid(color=(0.9, 0.9, 0.9), linewidth=0.3)
    ax.spines[:].set_color((0.9, 0.9, 0.9))
    ax.tick_params(axis='both', colors="black")
    ax.yaxis.label.set_color((0, 0, 0))
    ax.xaxis.label.set_color((0, 0, 0))
    # ax.set_ylim(yrange)
    plt.setp(ax.get_xticklabels(), fontsize=fontsize)
    plt.setp(ax.get_yticklabels(), fontsize=fontsize)

    allhandles, alllabels = ax.get_legend_handles_labels()
    by_label = {k: v for k, v in zip(alllabels, allhandles)}
    leg = fig.legend(by_label.values(), by_label.keys(),
                      loc='upper center', ncol=7, frameon=False,
                      fontsize=fontsize, facecolor="white", markerscale=2)
    fig.tight_layout(rect=[0, 0, 1, 0.87])
    fp, fn, fex = fileparts(outfile)
    outfile = fr"{fp}\{fn}_npc{npc}{fex}"
    plt.savefig(outfile, dpi=300)
    plt.show(block=False)
    plt.pause(0.01)
    plt.close('all')

    if outcsv is not None:
        d = {
            'Class': np.array(strclasses)[np.int32(classes)-1],
            'ClassID': classes,
            'UMAP1': umap_embedding[:, 0],
            'UMAP2': umap_embedding[:, 1],
            'TSNE1': tsne_embedding[:, 0],
            'TSNE2': tsne_embedding[:, 1],
             }
        df = pd.DataFrame(data=d)
        df.to_csv(outcsv, index=False)
