from .utils import *
import warnings

warnings.simplefilter(action='ignore', category=FutureWarning)
outdir=r".\qsaru_output"
mkdir(outdir)


def classification_table1():
    """classification table for each experiment of 1-3"""
    basedirs = [
        rf"{global_data_folder}/exp1",
        rf"{global_data_folder}/exp2",
        rf"{global_data_folder}/exp3",
    ]
    iclasses = [
        [1, 2, 3, 4, 5, 6, 7],
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        [1, 2, 3, 4, 5, 6, 7, 8, 9],
    ]
    grid = 3
    for j, basedir in enumerate(basedirs):
        csv_files_class = [
            fr"{basedir}_ingaas_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",  # _wo_image_replicate
            fr"{basedir}_ingaas_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",  # _wo_image_replicate
            fr"{basedir}_ingaas_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",  # _wo_image_replicate
            fr"{basedir}_ingaas_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",  # _wo_image_replicate
            fr"{basedir}_ingaas_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",  # _wo_image_replicate
            fr"{basedir}_mct_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",
            fr"{basedir}_mct_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",
            fr"{basedir}_mct_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",
            fr"{basedir}_mct_mp123_spec_div_polar{grid}x{grid}_wo_image_replicate.csv",
        ]
        wavelength_f_class = [
            fr"{global_data_folder}\ingaas_wavelengths.csv",
            fr"{global_data_folder}\ingaas_wavelengths.csv",
            fr"{global_data_folder}\ingaas_wavelengths.csv",
            fr"{global_data_folder}\ingaas_wavelengths.csv",
            fr"{global_data_folder}\ingaas_wavelengths.csv",
            fr"{global_data_folder}\mct_wavelengths.csv",
            fr"{global_data_folder}\mct_wavelengths.csv",
            fr"{global_data_folder}\mct_wavelengths.csv",
            fr"{global_data_folder}\mct_wavelengths.csv",
        ]
        xlims_class = [
            [800, 1600],
            [800, 1000],
            [1000, 1200],
            [1200, 1400],
            [1400, 1600],
            [1000, 2500],
            [1000, 1600],
            [1600, 2000],
            [2000, 2500],
        ]
        ndiffs = [5, 5, 5, 5, 5, 9, 9, 9, 9]
        npcs = [37, 37, 37, 37, 37, 27, 27, 27, 27]
        for i, csv_file in enumerate(csv_files_class):
            classification_pca_spectra_microplastic_1st(csv_file, wavelength_f_class[i],
                                                        xlims_class[i], npc=npcs[i], ndiff=ndiffs[i],
                                                        iclasses=iclasses[j])


def classification_table2():
    """classification table for combined datasets"""
    basedir = rf"{global_data_folder}"
    iga_csvfile = rf"{basedir}\ingaas_all_mp123_spec_div_polar3x3.csv"
    mct_csvfile = rf"{basedir}\mct_all_mp123_spec_div_polar3x3.csv"
    iga_wavelenfile = fr"{basedir}\ingaas_wavelengths.csv"
    mct_wavelenfile = fr"{basedir}\mct_wavelengths.csv"

    csv_files = [
        iga_csvfile,
        mct_csvfile,
    ]
    wavelength_f = [
        iga_wavelenfile,
        mct_wavelenfile,
    ]
    xlims_class = [[
        [800, 1600],
        [800, 1000],
        [1000, 1200],
        [1200, 1400],
        [1400, 1600]],
        [[1000, 2500],
         [1000, 1600],
         [1600, 2000],
         [2000, 2500]]
    ]
    ndiffs = [5, 9]

    npcs_cls = [37, 15]
    # # 20 classes
    class_groups0 = None
    # # 13 classes instead of 20 classes
    class_groups1 = {
        1: 1,
        2: 2, 3: 2,
        4: 3, 5: 3,
        6: 4, 7: 4,
        8: 5, 9: 5,
        10: 6,
        11: 7,
        12: 8, 13: 8,
        14: 9, 15: 9,
        16: 10, 17: 10,
        18: 11,
        19: 12,
        20: 13,
    }
    # # 7 classes
    class_groups2 = {
        1: 1,
        2: 2, 3: 2, 4: 2, 5: 2,
        6: 3, 7: 3, 8: 3, 9: 3,
        10: 4, 11: 4,
        12: 5, 13: 5, 14: 5, 15: 5,
        16: 6, 17: 6, 18: 6,
        19: 7, 20: 7,
    }
    # 5 classes
    class_groups3 = {
        1: 1,
        2: 2, 3: 2, 4: 2, 5: 2,
        6: 2, 7: 2, 8: 2, 9: 2,
        10: 3, 11: 3,
        12: 4, 13: 4, 14: 4, 15: 4,
        16: 4, 17: 4, 18: 4,
        19: 5, 20: 5,
    }
    cgroups = [class_groups0, class_groups1, class_groups2, class_groups3]
    for class_groups in cgroups:
        for i, csv_file in enumerate(csv_files):
            for j, xlim in enumerate(xlims_class[i]):
                classification_pca_spectra_microplastic_2nd(csv_file, wavelength_f[i], xlim, class_group=class_groups,
                                                            npc=npcs_cls[i], ndiff=ndiffs[i])


def spectral_plots_pure_samples():
    """to plot PURE MP spectra from the first dataset (2023_0125)"""

    basedir = rf"{global_data_folder}/exp1"
    csv_files = [
        fr"{basedir}_ingaas_mp123_spec.csv",
        fr"{basedir}_mct_mp123_spec.csv",
    ]
    wavelength_f = [
        fr"{global_data_folder}\ingaas_wavelengths.csv",
        fr"{global_data_folder}\mct_wavelengths.csv",
    ]
    outfiles = [
        fr"{outdir}\ingaas_spec_z.tif",
        fr"{outdir}\mct_spec_z.tif",
    ]
    xlims = [[800, 1600], [1000, 2500]]
    ndiffs = [5, 9]
    for i, csv_file in enumerate(csv_files):
        plot_spectra_zsoil_microplastic_pure_snv(csv_file, wavelength_f[i],
                                                 xlims[i], outfiles[i],
                                                 is_zscore=False, ndiff=ndiffs[i],
                                                 )  # outcsv=outcsvs_zsoil[i])


def spectral_plots_combined_dataset():
    """ To plot spectra of different microplastic concentrations of PE and PA in combined data."""

    basedir = rf"{global_data_folder}"
    iga_csvfile = rf"{basedir}\ingaas_all_mp123_spec_div_polar3x3.csv"
    mct_csvfile = rf"{basedir}\mct_all_mp123_spec_div_polar3x3.csv"

    iga_wavelenfile = fr"{basedir}\ingaas_wavelengths.csv"
    mct_wavelenfile = fr"{basedir}\mct_wavelengths.csv"

    csv_files = [
        iga_csvfile,
        mct_csvfile,
    ]
    wavelength_f = [
        iga_wavelenfile,
        mct_wavelenfile,
    ]
    outfiles = [
        fr"{outdir}\ingaas_zsoil_spec_snv.tif",
        fr"{outdir}\mct_zsoil_spec_snv.tif",
    ]
    xlims = [[800, 1600], [1000, 2500]]
    plims = [
        [[0, 14], [0, 14]],
        [[0, 10], [0, 10]],
        [[0, 14], [0, 14]],
    ]
    ndiffs = [5, 9]
    npcs = [
        [27, 19],
        [37, 37],
        [34, 54],
    ]

    class_groups = None
    ylims = [[-0.5, 0.5], [-1, 1]]
    for i, csv_file in enumerate(csv_files):
        plot_spectra_zsoil_microplastic_snv(csv_file, wavelength_f[i],
                                            xlims[i], outfiles[i],
                                            is_zscore=False, ndiff=ndiffs[i],
                                            ylim=ylims[i])


def tsne_umap_plots():
    """ t-SNE and UMAP charts using PCA."""
    basedir = rf"{global_data_folder}"
    iga_csvfile = rf"{basedir}\ingaas_all_mp123_spec_div_polar3x3.csv"
    mct_csvfile = rf"{basedir}\mct_all_mp123_spec_div_polar3x3.csv"
    iga_wavelenfile = fr"{basedir}\ingaas_wavelengths.csv"
    mct_wavelenfile = fr"{basedir}\mct_wavelengths.csv"

    csv_files = [
        iga_csvfile,
        mct_csvfile,
    ]
    wavelength_f = [
        iga_wavelenfile,
        mct_wavelenfile,
    ]
    xlims = [[800, 1600], [1000, 2500]]
    ndiffs = [5, 9]

    outfiles_pca_further = [
        fr"{outdir}\ingaas_umap_tsne.tif",
        fr"{outdir}\mct_umap_tsne.tif",
    ]
    npcs = [39, 14]
    for i, csv_file in enumerate(csv_files):
        plot_umap_tsne_spectra_mp(csv_file, wavelength_f[i], xlims[i], outfiles_pca_further[i],
                                  npc=npcs[i], ndiff=ndiffs[i], by_experiment=False)

