import math
from scipy import signal
import os
import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import PLSRegression
from sklearn.base import TransformerMixin, ClassifierMixin, BaseEstimator
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import accuracy_score


def fileparts(filename):
    """Separate file path to folder, file name, and extension
     Args:
          filename: file name string
     Output:
          folder, filename, file_extension
    """
    path, file_extension = os.path.splitext(filename)
    folder, filename = os.path.split(path)
    return folder, filename, file_extension


def subfolder_path_package(packagename, subfoldername):
    import importlib.util
    # Get the spec object for the package
    spec = importlib.util.find_spec(packagename)
    # Get the path of the package
    package_path, _, _ = fileparts(spec.origin)
    # Get the path of the subfolder
    subfolder_path = os.path.join(package_path, subfoldername)
    # Print the path of the subfolder
    return subfolder_path


# is_testing_module must be always False for this module to be installed.
# True for only testing
is_testing_module = False
if is_testing_module:
    global_data_folder = "./data"
else:
    global_data_folder = subfolder_path_package("mp_hsi", "data")


def msc(x, xref=None):
    """Multiplicative Scatter Correction converted from
            Matlab code by Cleiton A. Nunes

    x_msc = msc(x,xref)

    input
    x (samples x variables)      spectra to correct
    xref (1 x variables)         reference spectra (in general mean(x) is used)

    Output
    x_msc (samples x variables)  corrected spectra
    """
    m, n = x.shape

    if xref is None:
        rs = x.mean(axis=0)
    else:
        rs = xref

    cw = np.ones((1, n))
    mz = np.hstack((np.ones((n,1)), np.reshape(rs, (n, 1))))
    mm, nm = mz.shape
    wmz = mz * (np.transpose(cw) @ np.ones((1, nm)))  # '*' elementwise multiply and '@' matrix multiply
    wz = x * (np.ones((m, 1)) @ cw)
    z = np.transpose(wmz) @ wmz
    z = z.astype(np.float64)
    u, s, v = np.linalg.svd(z)
    sd = s  # instead of np.transpose(np.diag(s))
    cn = pow(10, 12)
    ms = sd[0] / math.sqrt(cn)
    cs = [max(sdi, ms) for sdi in sd]
    cz = u @ (np.diag(cs)) @ np.transpose(v)
    zi = np.linalg.inv(cz)
    b = zi @ np.transpose(wmz) @ np.transpose(wz)
    B = np.transpose(b)
    x_msc = x
    p = np.reshape(B[:, 0], (B.shape[0],1))
    x_msc = x_msc - (p @ np.ones((1, mm)))
    p = np.reshape(B[:, 1], (B.shape[0],1))
    x_msc = x_msc / (p @ np.transpose(np.ones((mm, 1))))
    return x_msc


def spec_angle(x, y):
    """spectral angle distance"""
    # print(f"x shape: {x.shape}, y shape: {y.shape}")
    xy = np.sum(x*y)
    xx = np.sum(x*x)
    yy = np.sum(y*y)
    ret = math.acos(xy/math.sqrt(xx*yy))
    # print(f"ret: {ret}")
    return ret


def snv(input_data):
    """Define a new array and populate it with the corrected data by Daniel Pelliccia"""
    data_snv = np.zeros_like(input_data)
    for i in range(input_data.shape[0]):
        data_snv[i, :] = (input_data[i, :] - np.mean(input_data[i, :])) / np.std(input_data[i, :], ddof=1)
    return data_snv


def zsnv(input_data):
    from scipy import stats
    data_snv = snv(input_data)
    data_zsnv = stats.zscore(data_snv)
    return data_zsnv



def snv_row(input_data):
    """Define a new array and populate it with the corrected data by Daniel Pelliccia"""
    data_snv = (input_data - np.mean(input_data)) / np.std(input_data, ddof=1)
    return data_snv


def difference(data, gap, direction):
    """
    DIFFERENCE implements the first order derivative.

        out = Difference( data, gap, direction)

        The first "gap" points are discard.
        Thus, the size of out is (n-gap).
    """
    if len(data.shape) != 2 or gap <= 0:
        raise ValueError('not supported dimension. should be 2')
    out = None
    if min(data.shape) == 1:
            out = data[gap:] - data[:-gap]
    else:
        if direction == 'column':
            out = data[gap:, :] - data[:-gap, :]
        elif direction == 'row':
            out = data[:, gap:] - data[:, :-gap]
        else:
            raise ValueError('not supported direction')
    return out


def detrend_polyfit(X, order=2):
    """
    DETRENDPOLYFIT Removes a non-linear trend from each column of a matrix. The nonlinearity is
       estimated with polynomial fit.

        Y = detrendpolyfit(X, *varargin)

        X is the input matrix.
        varargin is an integer number representing polynomial order. Its default value is 2.

        Returns values subtracted polynomial fit of order varargin from the input data X
    """
    if len(X.shape) < 2:
        X = np.reshape(X, (1, len(X)))
    Y = np.zeros(X.shape)
    for i in range(X.shape[1]):
        x = X[:, i]
        rng = [z+1 for z in range(len(x))]
        p = np.polyfit(np.transpose(rng), x[:], order)
        Y[:, i] = x[:]-np.polyval(p, np.transpose(rng))
    return Y


def deriv_norrisgap(X, gap, direction):
    """
    first derivative using Norris Gap
    :param X: m x n matrix
    :param gap: gap < n
    :param direction: 'row' or 'column'
    :return: Xout
    """
    if len(X.shape) != 2:
        raise ValueError('not supported dimension. should be 2')

    gap = gap + 1
    if min(X.shape) == 1:
        out = X[gap:] - X[:-gap]
    else:
        if direction == 'column':
            out = X[gap:, :] - X[:-gap, :]
        elif direction == 'row':
            out = X[:, gap:] - X[:, :-gap]

    out = out / gap
    Xout = rearrange_norrisgap(X, out)
    return Xout


def rearrange_norrisgap(X, out):
    """Re-arrage norris gap output"""
    M1, N1 = X.shape
    M2, N2 = out.shape
    if M2 < M1:
        # vertical direction
        offset = M1 - M2
        numPts = M2
        direction = 0
    elif N2 < N1:
        # horizontal direction
        offset = N1 - N2
        numPts = N2
        direction = 1
    else:
        raise ValueError('Error in Derivative_NorisGap')
    pos1 = np.int32(offset / 2)
    pos2 = np.int32(pos1 + numPts)
    Xout = np.float64(np.zeros_like(X))
    if direction == 0:
        Xout[pos1:pos2, :] = out
    elif direction == 1:
        Xout[:, pos1:pos2] = out
    return Xout


def expandarr(x,k):
    #make it work for 2D or nD with axis
    kadd = k
    if np.ndim(x) == 2:
        kadd = (kadd, np.shape(x)[1])
    return np.r_[np.ones(kadd)*x[0],x,np.ones(kadd)*x[-1]]


def movmoment(x, k, windowsize=3, lag='lagged'):
    """non-central moment
    Parameters
    ----------
    x : array
       time series data
    windsize : int
       window size
    lag : 'lagged', 'centered', or 'leading'
       location of window relative to current position

    Returns
    -------
    mk : array
        k-th moving non-central moment, with same shape as x
    Notes
    -----
    If data x is 2d, then moving moment is calculated for each
    column.
    """

    from scipy import signal
    windsize = windowsize
    #if windsize is even should it raise ValueError
    if lag == 'lagged':
        #lead = -0 + windsize #windsize//2
        lead = -0# + (windsize-1) + windsize//2
        sl = slice((windsize-1) or None, -2*(windsize-1) or None)
    elif lag == 'centered':
        lead = -windsize//2  #0#-1 #+ #(windsize-1)
        sl = slice((windsize-1)+windsize//2 or None, -(windsize-1)-windsize//2 or None)
    elif lag == 'leading':
        #lead = -windsize +1#+1 #+ (windsize-1)#//2 +1
        lead = -windsize +2 #-windsize//2 +1
        sl = slice(2*(windsize-1)+1+lead or None, -(2*(windsize-1)+lead)+1 or None)
    else:
        raise ValueError

    avgkern = (np.ones(windowsize)/float(windowsize))
    xext = expandarr(x, windsize-1)
    # Note: expandarr increases the array size by 2*(windsize-1)
    # sl = slice(2*(windsize-1)+1+lead or None, -(2*(windsize-1)+lead)+1 or None)
    # print(sl)

    if xext.ndim == 1:
        return np.correlate(xext**k, avgkern, 'full')[sl]
        # return np.correlate(xext**k, avgkern, 'same')[windsize-lead:-(windsize+lead)]
    else:
        # print(xext.shape)
        # print(avgkern[:,None].shape)

        # try first with 2d along columns, possibly ndim with axis
        return signal.correlate(xext**k, avgkern[:,None], 'full')[sl, :]


def movmean(x, windowsize=3, mode="same"):
    """moving window mean
    Parameters
    ----------
    x : array
       time series data
    windsize : int
       window size
    mode : string
        "same" - output array has same size as input
        "valid" - output array has reduced ize from input containing non-truncated values
    Returns
    -------
    mk : array
        moving mean, with same shape as x
    Notes
    -----
    When mode="same"
    The window size is automatically truncated at the endpoints
    when there are not enough elements to fill the window.
    When the window is truncated, the average is taken over
    only the elements that fill the window.
    """
    if type(x) is not np.ndarray:
        raise ValueError("input should be numpy ndarray!")

    lag = 'centered'
    ret = movmoment(x, 1, windowsize=windowsize, lag=lag)

    # to handle truncated window operations correctly
    n = windowsize//2
    if x.ndim == 2 and min(x.shape) > 1:
        for i in range(n):
            ret[i, :] = np.mean(x[:(i + n + 1), :], axis=0)
            ret[-(i + 1), :] = np.mean(x[-(i + n + 1):, :], axis=0)
    elif x.ndim == 1 or (x.ndim == 2 and min(x.shape) == 1):
        for i in range(n):
            ret[i] = np.mean(x[:(i + n + 1)])
            ret[-(i + 1)] = np.mean(x[-(i + n + 1):])
        pass
    else:
        raise ValueError("input dimension should be <= 2!")

    # remove values calculated with truncated window size in "valid" mode
    if mode == "valid":
        if x.ndim == 2 and min(x.shape) > 1:
            ret = ret[n:-n,:]
        elif x.ndim == 1 or (x.ndim == 2 and min(x.shape) == 1):
            ret = ret[n:-n]
    return ret


def msc_diff_ma(x, gap=7):
    """MSC+Difference+Moving average"""
    res = msc(x)
    res = difference(res, gap, 'row')
    res = movmean(res.T, gap, 'same').T
    return res


def msc_diff(x, gap=7):
    """MSC+Difference+Moving average"""
    res = msc(x)
    res = difference(res, gap, 'row')
    return res


def msc_ma(x, gap=7):
    """MSC+Moving average"""
    res = msc(x)
    res = movmean(res.T, gap, 'same').T
    return res


def snvd_diff_ma(x, gap=7):
    """SNV+Detrending+Difference+Moving average"""
    res = snv(x)
    res = signal.detrend(res)
    res = difference(res, gap, 'row')
    res = movmean(res.T, gap, 'same').T
    return res


def snvd_diff(x, gap=7):
    """SNV+Detrending+Difference+Moving average"""
    from statsmodels.tsa.tsatools import detrend
    res = snv(x).astype(np.float64)
    res1 = detrend(res, axis=1)
    res2 = difference(res1, gap, 'row')
    return res2


def detrend_diff(x, gap=7):
    """SNV+Detrending+Difference+Moving average"""
    from statsmodels.tsa.tsatools import detrend
    res = x.astype(np.float64)
    res1 = detrend(res, axis=1)
    res2 = difference(res1, gap, 'row')
    return res2

def snvd_2diff(x, gap=7):
    """SNV+Detrending+Difference+Moving average"""
    from statsmodels.tsa.tsatools import detrend
    res = snv(x).astype(np.float64)
    res1 = detrend(res, axis=1)
    res2 = difference(res1, gap, 'row')
    res3 = difference(res2, gap, 'row')
    return res3


def snvd_ma(x, gap=7):
    """SNV+Detrending++Moving average"""
    res = snv(x)
    res = signal.detrend(res)
    res = movmean(res.T, gap, 'same').T
    return res


def savgol(input, winsize=25, poly=4, axis=1):
    from scipy.signal import savgol_filter
    out = savgol_filter(input, winsize, polyorder=poly, axis=axis)
    return out


def read_wavelengths(filename):
    """return wavelengths saved with write_csv_single_col"""
    # print(filename)
    with open(filename, 'r') as fp:
        wavelengths = [float(line.rstrip('\n')) for line in fp]
    return wavelengths


class PLSDA(TransformerMixin, ClassifierMixin):
    def __init__(self, n_components=2):
        self.n_components = n_components
        self.pls = PLSRegression(n_components=self.n_components, max_iter=100000)

    def fit(self, X, Y, sample_weight=None):
        enc = OneHotEncoder()
        if not isinstance(Y, np.ndarray):
            Y = np.array(Y)

        Y_proba = enc.fit_transform(np.reshape(Y, (-1, 1))).toarray()
        self.labels = enc.categories_[0]
        self.pls.fit(X, Y_proba)

        self.x_weights_ = self.pls.x_weights_
        self.x_loadings_ = self.pls.x_loadings_
        self.x_rotations_ = self.pls.x_rotations_
        self.x_scores_ = self.pls.x_scores_
        self.y_weights_ = self.pls.y_weights_
        self.y_loadings_ = self.pls.y_loadings_
        self.y_rotations_ = self.pls.y_loadings_
        self.y_scores_ = self.pls.y_scores_
        self.coef_ = self.pls.coef_

        return self

    def transform(self, X):
        return self.pls.transform(X)

    def fit_transform(self, X, Y):
        return self.fit(X, Y).transform(X)

    def predict(self, X):
        pred_proba = self.pls.predict(X)
        idxs = np.argmax(pred_proba, axis=1)
        return np.reshape(self.labels[idxs], (-1, 1))

    def score(self, X, Y, sample_weight=None):
        if sample_weight is None:
            return accuracy_score(Y, self.predict(X))
        else:
            return accuracy_score(Y, self.predict(X * sample_weight[:, None]))

    def set_params(self, **params):
        for a in params:
            if a == 'n_components':
                self.pls.set_params(n_components=params[a])

    def __repr__(self):
        return f'PLSDA(n_components={self.n_components})'

    def __str__(self):
        return repr(self)


class PCADA(TransformerMixin, ClassifierMixin):
    def __init__(self, n_components=2):
        self.n_components = n_components
        self.pca = PCA(n_components=self.n_components)
        self.reg = LinearRegression()

    def fit(self, X, Y):
        enc = OneHotEncoder()
        if not isinstance(Y, np.ndarray):
            Y = np.array(Y)

        Y_proba = enc.fit_transform(np.reshape(Y, (-1, 1))).toarray()
        self.labels = enc.categories_[0]
        pca_reduced = self.pca.fit_transform(X)
        self.reg = self.reg.fit(pca_reduced, Y_proba)
        self.x_loadings_ = self.pca.components_
        self.x_scores_ = pca_reduced
        self.coef_ = self.reg.coef_

        return self

    def transform(self, X):
        return self.pca.transform(X)

    def fit_transform(self, X, Y):
        return self.fit(X, Y).transform(X)

    def predict(self, X):
        X_reduced = self.transform(X)
        pred_proba = self.reg.predict(X_reduced)
        # print(pred_proba.shape)
        idxs = np.argmax(pred_proba, axis=1)
        return np.reshape(self.labels[idxs], (-1, 1))

    def score(self, X, Y, sample_weight=None):
        if sample_weight is None:
            return accuracy_score(Y, self.predict(X))
        else:
            return accuracy_score(Y, self.predict(X * sample_weight[:, None]))

    def set_params(self, **params):
        for a in params:
            if a == 'n_components':
                self.pca.set_params(n_components=params[a])

    def __repr__(self):
        return f'PCADA(n_components={self.n_components})'

    def __str__(self):
        return repr(self)