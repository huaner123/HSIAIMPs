from setuptools import setup, find_packages

VERSION = '0.0.1' 
DESCRIPTION = 'MP detection with SWIR HSIs'
LONG_DESCRIPTION = 'mp_hsi package contains necessary function and data to classify microplastic concentration of samples with shoft-wave infrared hyperspectral imaging'

# Setting up
setup(
        name="mp_hsi", 
        version=VERSION,
        author="Taesung Shin",
        author_email="<taesung.shin@usda.gov>",
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=[
            "opencv-python", 
            "spectral", 
            "scikit-learn",
            "tifffile",
            "matplotlib",
            "pandas",
            "statsmodels",
            "umap-learn",
            "distinctipy",
        ], 
        package_data={'mp_hsi': [
            "data\ingaas_all_mp123_spec_div_polar3x3.csv",
            "data\mct_all_mp123_spec_div_polar3x3.csv",
            "data\ingaas_wavelengths.csv",
            "data\mct_wavelengths.csv",
            "data\exp1_mct_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp1_ingaas_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp2_mct_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp2_ingaas_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp3_mct_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp3_ingaas_mp123_spec_div_polar3x3_wo_image_replicate.csv",
            "data\exp1_mct_mp123_spec.csv",
            "data\exp1_ingaas_mp123_spec.csv",
            ]},
        keywords=['python', 'microplastics', 'short-wave infrared', 'hyperspectral imaging'],
        classifiers= [
            "Development Status :: 3 - Alpha",
            "Intended Audience :: Education",
            "Programming Language :: Python :: 3",
            "Operating System :: Microsoft :: Windows",
        ]
)