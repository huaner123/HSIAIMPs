### MP detection with SWIR HSI

This package was developed for studies of MP concentration classification with hyperspectral imaging. It currently contains scripts and data for the following results. 

    • Table 1 for classification results with individual datasets
    • Table 2 for classification results with combined datasets
    • t-SNE charts (and probably UMAP charts)
    • Spectral charts without Z scoring

### Instruction to install and run the package (in Windows 10):

1. Create a folder and make a virtual environment in command prompt
```
mkdir qsaru_test
cd qsaru_test
python -m venv venv
venv\scripts\activate
```

2. Copy mp_hsi.zip into the created folder, and install the package
```
pip install mp_hsi.zip
```

3. Create test_mp_hsi.py with the following content

```
from mp_hsi import *
# spectral_plots_pure_samples()
# spectral_plots_combined_dataset()
# tsne_umap_plots()
classification_table1()  # this may take an hour to finish all hyperparameter optimizations
# classification_table2()  # this may take days (e.g., 4 days) to finish all hyperparameter optimizations
```

4. The command below should create qsaru_output subfolder and produce extracted data.
```
python test_mp_hsi.py 
```

### Contact information:

If you have any questions, feel free to contact Dr. Bosoon Park (bosoon.park@usda.gov).